package gnc.mo;

import gnc.pojo.IGRN;

public abstract interface IDist
{
  public abstract int[][] distFloydWarshall(IGRN paramIGRN);
}
