/*     */ package gnc.mo;
/*     */ 
/*     */ import gnc.pojo.Edge;
/*     */ import gnc.pojo.IGRN;
/*     */ import gnc.pojo.Node;
/*     */ import java.util.ArrayList;
import gnc.utils.Utils;
/*     */ import java.util.List;
/*     */ 
/*     */ public class DistFloyd extends Thread
/*     */   implements IDist
            
/*     */ {
/*     */   public int[][] distFloydWarshall(IGRN grn)
/*     */   {
/*  23 */     int[][] path = getAdyMatriz(grn);
/*     */     float complete = (float)0;
/*     */     int cont = 0;
/*  25 */     int cn = grn.getNodeList().size();
/*     */ 
/*  27 */     for (int k = 0; k < cn; k++)
/*     */     {
/*  29 */       for (int i = 0; i < cn; i++)
/*     */       {
/*  31 */         for (int j = 0; j < cn; j++)
/*     */         {
/*  33 */           int dt = path[i][k] + path[k][j];
/*     */ 
/*  35 */           if (path[i][j] > dt)
/*     */           {
/*  37 */             path[i][j] = dt;
/*     */           }
/*     */         }
                        
/*     */       }
                float valueAdd = (float)((float)Utils.twenty/(float)cn);
                complete+=valueAdd;
                if ((float)complete>=(float)Utils.unit) {                
                    Utils.updateProcess((int)complete);
                    Utils.printProcessValue();                    
                    complete = (float)0.0;
                }         
/*     */     }
/*  43 */     return path;
/*     */   }
/*     */ 
/*     */   public int[][] getAdyMatriz(IGRN grn)
/*     */   {
/*  49 */     int[][] m = new int[grn.getNodeList().size()][grn.getNodeList().size()];
/*     */ 
/*  52 */     for (int i = 0; i < grn.getNodeList().size(); i++)
/*     */     {
/*  55 */       List vecinos = new ArrayList();
/*     */ 
/*  58 */       for (int k = 0; k < ((Node)grn.getNodeList().get(i)).getIdAristas().size(); k++)
/*     */       {
/*  60 */         if (((Edge)grn.getEdgeList().get(((Integer)((Node)grn.getNodeList().get(i)).getIdAristas().get(k)).intValue() - 1)).getDestino().compareToIgnoreCase(((Node)grn.getNodeList().get(i)).getNombre()) == 0)
/*     */         {
/*  62 */           vecinos.add(((Edge)grn.getEdgeList().get(((Integer)((Node)grn.getNodeList().get(i)).getIdAristas().get(k)).intValue() - 1)).getOrigen());
/*     */         }
/*     */         else
/*     */         {
/*  66 */           vecinos.add(((Edge)grn.getEdgeList().get(((Integer)((Node)grn.getNodeList().get(i)).getIdAristas().get(k)).intValue() - 1)).getDestino());
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*  71 */       for (int j = 0; j < grn.getNodeList().size(); j++)
/*     */       {
/*  74 */         if (i == j)
/*     */         {
/*  76 */           m[i][j] = Utils.same_edge;
/*     */         }
/*  81 */         else if (vecinos.contains(((Node)grn.getNodeList().get(j)).getNombre()))
/*     */         {
/*  83 */           m[i][j] = Utils.unit;
/*     */         }
/*     */         else
/*     */         {
/*  88 */           m[i][j] = Utils.infinite;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*  94 */       vecinos.clear();
/*     */     }
/*     */ 
/*  97 */     return m;
/*     */   }/*     */ 

/*     */ }

