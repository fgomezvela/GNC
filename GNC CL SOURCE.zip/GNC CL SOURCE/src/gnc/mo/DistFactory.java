/*    */ package gnc.mo;
/*    */ 
/*    */ public class DistFactory
/*    */ {
/* 16 */   private static DistFactory INSTANCE = null;
/*    */ 
/*    */   private static void createInstance()
/*    */   {
/* 20 */     if (INSTANCE == null)
/*    */     {
/* 22 */       INSTANCE = new DistFactory();
/*    */     }
/*    */   }
/*    */ 
/*    */   public static DistFactory getInstance()
/*    */   {
/* 28 */     if (INSTANCE == null)
/*    */     {
/* 30 */       createInstance();
/*    */     }
/*    */ 
/* 33 */     return INSTANCE;
/*    */   }
/*    */ 
/*    */   public IDist createGRN(String tipo)
/*    */   {
/* 38 */     if (tipo.compareTo("Floyd") == 0)
/*    */     {
/* 40 */       return new DistFloyd();
/*    */     }            
/* 44 */     return null;
/*    */   }
/*    */ }
