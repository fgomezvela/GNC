/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gnc.mo;

import gnc.pojo.IGRN;
import gnc.pojo.ReadGRN;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import static java.lang.System.out;
import javax.swing.JOptionPane;
import gnc.utils.Utils;

/**
 *
 * @author JoseAntonio
 */
public class GNCThread extends Thread {

    private IGRN grn;
    private ReadGRN lee;
    private String type;
    private int[][] matrix;
    private IDist dist;
    private String name;
    public static Integer numExecuted = new Integer(0);
    public static Thread main = new Thread();
    private MeasuresCalculator cm;
    private String path;

    public GNCThread(IGRN grn, ReadGRN lee, String type, String name, int[][] matrix, IDist dist, MeasuresCalculator cm, String path) {
        this.grn = grn;
        this.lee = lee;
        this.type = type;
        this.matrix = matrix;
        this.dist = dist;
        this.name = name;
        this.cm = cm;
        this.path = path;
    }

    public void run() {
        boolean flag = true;
        try {
            out.print("Reading " + type + "\n");
            if (type.compareToIgnoreCase("Database") == 0) {
                this.grn = this.lee.readFile(path, type);
                this.cm.setGrnBD(grn);
            } else {
                this.grn = this.lee.readFile(path, type);
                this.cm.setInputGRN(grn);
                flag = false;
            }
            out.print(type + " have been read" + "\n");
            out.print("Loading " + type + "\n");
            matrix = dist.distFloydWarshall(grn);

            out.print("Distance matrix for "+ type +" has been calculated successfully" + "\n");

            if (flag) {
                this.cm.setmBD(matrix);
            } else {
                this.cm.setmIn(matrix);
            }
        } catch (FileNotFoundException ex) {
            out.print("I can not find the " + type + " file" + "\n");
            System.exit(1);

        } catch (IOException ex) {
            out.print("I can not read " + type + " file" + "\n");
            System.exit(1);
        }

        synchronized (this.main) {
            numExecuted++;
            if (numExecuted == 2) {
                this.main.notify();
            }
        }
    }  
}
