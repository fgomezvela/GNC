/*    */ package gnc.pojo;
/*    */ 
/*    */ import gnc.bbdd.BBDD;
/*    */ import gnc.inputnetwork.RedEntrada;
/*    */ import java.util.List;
import gnc.utils.Utils;
/*    */ 
public class GRNFactory
/*    */ {
           
            private static GRNFactory instance=null;
    
    
            private   GRNFactory(){}
           
           public static GRNFactory getInstance(){
               if(instance == null)
                   instance=  new GRNFactory();
              return instance;
           
           }
    
/*    */   public IGRN createGRN(String grn, List<Node> listNodos, List<Edge> listAristas, String organismo)
/*    */   {
/* 22 */     if (grn.compareTo(Utils.BBDD) == 0)
/*    */     {
/* 24 */       return new BBDD(listNodos, listAristas, organismo);
/*    */     }
/* 26 */     if (grn.compareTo(Utils.INPUT_NETWORK) == 0)
/*    */     {
/* 28 */       return new RedEntrada(listNodos, listAristas);
/*    */     }
/*    */ 
/* 32 */     return null;
/*    */   }
/*    */ }
