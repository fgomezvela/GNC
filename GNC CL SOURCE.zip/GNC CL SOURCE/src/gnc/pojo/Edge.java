/*    */ package gnc.pojo;
/*    */ 
/*    */ public class Edge
/*    */ {
/*    */   private String startNode;
/*    */   private String endNode;
/*    */   private int idEdge;
/*    */ 
/*    */   public Edge(String startNode, String endNode, int idEdge)
/*    */   {
/* 19 */     this.startNode = startNode;
/* 20 */     this.endNode = endNode;
/* 21 */     this.idEdge = idEdge;
/*    */   }
/*    */ 
/*    */   public Edge(String startNode, String endNode) {
/* 25 */     this.startNode = startNode;
/* 26 */     this.endNode = endNode;
/*    */   }
/*    */ 
/*    */   public String getDestino()
/*    */   {
/* 31 */     return this.endNode;
/*    */   }
/*    */ 
/*    */   public int getIdArista()
/*    */   {
/* 36 */     return this.idEdge;
/*    */   }
/*    */ 
/*    */   public void setOrigen(String startNode) {
/* 40 */     this.startNode = startNode;
/*    */   }
/*    */ 
/*    */   public void setDestino(String endNode) {
/* 44 */     this.endNode = endNode;
/*    */   }
/*    */ 
/*    */   public String getOrigen()
/*    */   {
/* 49 */     return this.startNode;
/*    */   }
/*    */ }

