/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gnc.pojo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import static java.lang.System.out;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import gnc.utils.Utils;

/**
 *
 * @author Josele
 */
public class ReadGRN {

    String path, organismName;
    HashMap<String, Integer> hmap = new HashMap<String, Integer>();

    public ReadGRN() {
    }

    public String getOrganismName() {
        return organismName;
    }

    public void setOrganismName(String organismName) {
        this.organismName = organismName;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public ReadGRN(String ruta, String nOrganismo) {
        this.path = ruta;
        this.organismName = nOrganismo;
    }

    public HashMap<String, Integer> getHmap() {
        return hmap;
    }

    public void setHmap(HashMap<String, Integer> hmap) {
        this.hmap = hmap;
    }


    public IGRN readFile(String path, String type) throws FileNotFoundException, IOException {

        List<Edge> edge = new ArrayList<Edge>();
        List<Node> node = new ArrayList<Node>();
        int idArista = 1;

        File file = null;
        FileReader fr = null;
        FileReader fr2 = null;
        BufferedReader br = null;
        BufferedReader br2 = null;
        float cont = (float) 0;

      
        file = new File(path);
        fr = new FileReader(file);
        fr2 = new FileReader(file);
        br = new BufferedReader(fr);
        br2 = new BufferedReader(fr2);
        String line;
        String line2;
        Node aux, auxi;
        int conta = 0;
        int numLines = 0;
        try {
            long tamFile = file.length();
            String tamFileInfo;
            if (tamFile < 1024) {
                tamFileInfo = "under 1 KB";
            } 
            else if (tamFile > 1024 && tamFile < 1024 * 1024) {
                tamFileInfo = "under 1 MB";
            } else if (tamFile > 1024 * 1024 && tamFile < 2 * 1024 * 1024) {
                tamFileInfo = "under 2 MB";
            } else if (tamFile > 2 * 1024 * 1024 && tamFile < 5 * 1024 * 1024) {
                tamFileInfo = "under 5 MB";
            } else {
                tamFileInfo = "over 5 MB";
            }
            out.print("The selected " + type + " is " + tamFileInfo + ".\n");

            line = br.readLine();

            do {
                numLines++;
            } while ((line2 = br2.readLine()) != null);
            out.print("Reading " + type + " file: " + numLines + " lines\n");
            do {
                String[] split = line.split(",");
                if (split[0].contains("﻿")) {
                    aux = new Node(split[0].split("﻿")[1]);
                } else {
                    aux = new Node(split[0]);
                }
                auxi = new Node(split[1]);
                if (!node.contains(aux)) {
                    node.add(aux);
                    this.hmap.put(aux.getNombre(), conta);
                    conta++;

                }
                if (!node.contains(auxi)) {
                    node.add(auxi);
                    this.hmap.put(auxi.getNombre(), conta);
                    conta++;
                }
                Edge a = new Edge(aux.getNombre(), auxi.getNombre(), idArista);
                edge.add(a);

                float valueAdd = (float) ((float) Utils.fifteen / (float) numLines);
                cont += valueAdd;
                if ((float) cont >= (float) Utils.unit) {
                    Utils.updateProcess((int) cont);
                    Utils.printProcessValue();
                    cont = (float) 0.0;
                }
                idArista++;
            } while ((line = br.readLine()) != null);

            //Añadimos ID de Aristas a cada Nodo una vez que tenemos las listas
            for (int j = 0; j < node.size(); j++) {
                List<Integer> ar = new ArrayList<Integer>();

                for (int k = 0; k < edge.size(); k++) {
                    if (node.get(j).getNombre().compareToIgnoreCase(edge.get(k).getOrigen()) == 0 || node.get(j).getNombre().compareToIgnoreCase(edge.get(k).getDestino()) == 0) {
                        ar.add(edge.get(k).getIdArista());
                    }
                }
                node.get(j).setIdAristas(ar);
            }

        } catch (Exception e) {
            //System.out.println("Error leyendo el fichero: linea :" + idArista);
            out.print("File: " + file.getName() + ", format error, please revise line: " + idArista + "\n");
            e.printStackTrace();
            GRNFactory factoria = GRNFactory.getInstance();
            if (organismName == null) {
                return factoria.createGRN(Utils.INPUT_NETWORK, new ArrayList<Node>(), new ArrayList<Edge>(), organismName);
            } else {
                return factoria.createGRN(Utils.BBDD, new ArrayList<Node>(), new ArrayList<Edge>(), organismName);
            }
        } finally {
            try {
                if (null != fr) {
                    fr.close();
                    br.close();
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
        GRNFactory factory = GRNFactory.getInstance();
        if (organismName == null) {
            return factory.createGRN(Utils.INPUT_NETWORK, node, edge, organismName);
        } else {
            return factory.createGRN(Utils.BBDD, node, edge, organismName);
        }
    }

    public List<String> listaBD(String path) {

        List<String> nombreOrganismos = new ArrayList();

        File f = new File(path);

        for (int i = 0; i < f.list().length; i++) {
            String nombre = f.list()[i];
            nombreOrganismos.add(nombre.split("_")[0]);
        }

        return nombreOrganismos;

    }

    public List<String> listOrganism(String path) {
        List<String> nameDB = new ArrayList();

        File f = new File(path);

        for (int i = 0; i < f.list().length; i++) {
            String nombre = f.list()[i];
            if (!nameDB.contains(nombre.split("_")[1].split(".txt")[0])) {
                nameDB.add(nombre.split("_")[1].split(".txt")[0]);
            }
        }

        return nameDB;
    }   
}
