package gnc.pojo;

import java.util.List;

public abstract interface IGRN
{
  public abstract void addEdge(Edge paramArista);

  public abstract void addNode(Node paramNodo);

  public abstract List<Edge> getEdgeList();

  public abstract List<Node> getNodeList();

  public abstract void setEdgeList(List<Edge> paramList);

  public abstract void setNodeList(List<Node> paramList);

  public abstract Node searchName(String paramString);
}


