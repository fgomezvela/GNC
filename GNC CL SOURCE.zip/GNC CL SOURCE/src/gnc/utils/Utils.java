/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gnc.utils;

import static java.lang.System.out;

/**
 *
 * @author JoseAntonio
 */
public class Utils {
    public static final String INPUT_NETWORK ="RedEntrada";
    public static final String BBDD ="BBDD";
    ///////////////////////////////////////
    public static int infinite = 99;
    public static int same_edge = 0;
    public static int minimun_distance = 1;
    ///////////////////////////////////////
    public static int max = 100;
    public static int min = 0;
    public static int last_step = 70;
    public static int unit = 1;
    ///////////////////////////////////////
    public static String GNCFolder = System.getProperty("user.dir") + System.getProperty("file.separator") + "GNC";
    public static String pathComparaciones = System.getProperty("user.dir") + System.getProperty("file.separator") + "GNC" + System.getProperty("file.separator") + "Results";
    public static String pathFicheroComparaciones = System.getProperty("user.dir") + System.getProperty("file.separator") + "GNC" + System.getProperty("file.separator") + "Results" + System.getProperty("file.separator") + "Results.txt";
    public static String pathInput = System.getProperty("user.dir") + System.getProperty("file.separator") + "GNC" + System.getProperty("file.separator") + "InputNetworks";
    public static String pathDB = System.getProperty("user.dir") + System.getProperty("file.separator") + "GNC" + System.getProperty("file.separator") + "BioDatabases";
    public static String pathMatrices = System.getProperty("user.dir") + System.getProperty("file.separator") + "GNC" + System.getProperty("file.separator") + "Matrices";
    public static String pathHistorial = System.getProperty("user.home");
    ///////////////////////////////////////
    public static int ten   = 10;
    public static int five = 5;
    public static int twenty = 20;
    public static int fifteen = 15;
    ////////////////////////////////////////
    public static int completeTotalProcess = 0;
    ////////////////////////////////////////
    public static int info;
    
    
    public static void updateProcess(int i){
        Utils.completeTotalProcess += i;        
    }
    public static void printProcessValue(){
        if (Utils.completeTotalProcess % info ==0 && Utils.completeTotalProcess <=max ) {
            out.print("Total progress:" + completeTotalProcess + "% \n");
        }        
    }
    
    public static void updateInfo(int i){
        Utils.info = i;
    }    
}
