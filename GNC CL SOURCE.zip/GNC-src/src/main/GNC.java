package main;

import gnc.utils.ReadFromPropertiesSingleton;
import gnc.mo.MeasuresCalculator;
import gnc.pojo.Edge;
import gnc.pojo.GRNFactory;
import gnc.pojo.Node;
import java.io.File;
import static java.lang.System.out;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Properties;
import gnc.utils.Utils;

/**
 *
 * @author JoseAntonio & FGV
 */
public class GNC {

    public static void main(String[] args) throws InterruptedException {

        File archivoInput;
        File archivoBD;

        String inputNetworkPath, databasePath;

        boolean part1 = false, part2 = false, part3 = false, part4 = false;
        boolean emptyIN = false, checkIN = false;
        boolean emptyDB = false, checkDB = false;
        boolean property = false;

        Properties prop = ReadFromPropertiesSingleton.getInstance().getProp();

        inputNetworkPath = prop.getProperty("inputNetwork");
        databasePath = prop.getProperty("database");
        String intervalString = prop.getProperty("invertal");
        int interval = Utils.five;
        try {
            interval = Integer.parseInt(intervalString);
        } catch (Exception e) {
            out.print("Interfal by default set in " + Utils.five + "%\n");
        } finally {
            interval = Utils.five;
        };
        Utils.updateInfo(interval);

        MeasuresCalculator cm = new MeasuresCalculator(databasePath, inputNetworkPath);

        if ((!inputNetworkPath.isEmpty() || inputNetworkPath != null) && (!databasePath.isEmpty() || databasePath != null)) {
            property = true;
        }
        if (property) {
            if (!databasePath.isEmpty()) {
                part1 = true;
            } else {
                out.print("Please, choose a correct database file\n");
                System.exit(1);

            }
            if (!inputNetworkPath.isEmpty()) {
                part2 = true;
            } else {
                out.print("Please, choose a correct file as input network\n");
                System.exit(1);

            }
            if (part2 && part1) {
                part3 = true;
            }
            if (part3) {
                archivoInput = new File(inputNetworkPath);
                if (archivoInput.length() > 0) {
                    emptyIN = false;
                    checkIN = true;
                    part4 = true;
                } else {
                    emptyIN = true;
                    checkIN = false;
                }
                if (emptyIN) {
                    out.print("I can not read input network file, it is empty\n");
                    System.exit(1);

                }
            }
            if (part4) {
                archivoBD = new File(databasePath);
                if (archivoBD.length() > 0) {
                    emptyDB = false;
                    checkDB = true;
                } else {
                    emptyDB = true;
                    checkDB = false;
                }
                if (emptyDB) {
                    out.print("I can not read database file, it is empty\n");
                    System.exit(1);

                }
            }
            Calendar c1 = Calendar.getInstance();
            String[] date = c1.getTime().toString().split("CEST");
            out.print("Starting: " + date[0] + "\n");
            if (checkDB && checkIN && !emptyIN && !emptyDB) {
                String BD = calcularNombre(databasePath), input = calcularNombre(inputNetworkPath);
                cm.start(BD, input);
            } else {
                out.print("An error ocurred, please check the files path \n");
                System.exit(1);
            }
        }
    }

    public static String calcularNombre(String ruta) {
        int lastIndexSlash = ruta.lastIndexOf(System.getProperty("file.separator"));
        int lastIndexP = ruta.lastIndexOf(".");
        String input = "";
        if (lastIndexSlash == -1) {
            input = ruta.substring(0, lastIndexP);
        } else {
            input = ruta.substring(lastIndexSlash + 1, lastIndexP);
        }
        return input;
    }

}
