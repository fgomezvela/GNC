/*    */ package gnc.bbdd;
/*    */ 
/*    */ import gnc.pojo.Edge;
/*    */ import gnc.pojo.GRN;
/*    */ import gnc.pojo.Node;
/*    */ import java.util.List;
/*    */ 
/*    */ public class BBDD extends GRN
/*    */ {
/*    */   private String nOrganism;
/*    */ 
/*    */   public BBDD(List<Node> nodeList, List<Edge> edgesList, String nOrganism)
/*    */   {
/* 22 */     super(nodeList, edgesList);
/* 23 */     this.nOrganism = nOrganism;
/*    */   }
/*    */   public BBDD() 
/*    */   {
/*    */   }
 
/*    */   public String getnOrganism()
/*    */   {
/* 28 */     return this.nOrganism;
/*    */   }
/*    */ }

