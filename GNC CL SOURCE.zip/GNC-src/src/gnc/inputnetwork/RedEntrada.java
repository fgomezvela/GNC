/*    */ package gnc.inputnetwork;
/*    */ 
/*    */ import gnc.pojo.Edge;
/*    */ import gnc.pojo.GRN;
/*    */ import gnc.pojo.Node;
/*    */ import java.util.List;
/*    */ 
/*    */ public class RedEntrada extends GRN
/*    */ {

            public RedEntrada() {
            }
            
/*    */   public RedEntrada(List<Node> nodeList, List<Edge> edgesList)
/*    */   {
/* 21 */     super(nodeList, edgesList);
/*    */   }
/*    */ }
