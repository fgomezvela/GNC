package gnc.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import static java.lang.System.out;
import java.util.Properties;

public class ReadFromPropertiesSingleton {

	private static ReadFromPropertiesSingleton instance = null;
	private Properties prop;

	private ReadFromPropertiesSingleton() {

		this.prop = new Properties();
		InputStream input = null;

		try {

			input = new FileInputStream("config.properties");
			this.prop.load(input);

		} catch (IOException ex) {
                    out.print("Config.property file is not located in the current directory\n");
                    System.exit(1);
                    //ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					//e.printStackTrace();
				}
			}
		}
	}

	public static ReadFromPropertiesSingleton getInstance() {
		if (instance == null)
		 instance = new ReadFromPropertiesSingleton();
		
		return instance;
	}

	public Properties getProp() {
		return this.prop;
	}
}
