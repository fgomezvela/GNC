/*     */ package gnc.utils;
/*     */
import gnc.mo.Posiition;
/*     */ import gnc.pojo.Node;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileReader;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */
/*     */ public class Dump /*     */ {
    /*     */ public static void dumpFile(int[][] m, String path, String name)
            /*     */ throws IOException /*     */ {
        /*  25 */ String sFile = name;
        /*     */
        /*  27 */ FileWriter fichero = new FileWriter(path + System.getProperty("file.separator") + sFile);
        /*  28 */ BufferedWriter bw = new BufferedWriter(new FileWriter(sFile));
        /*     */
        /*  30 */ for (int x = 0; x < m.length; x++) {
            /*  31 */ for (int y = 0; y < m.length; y++) {
                /*  32 */ fichero.write(m[x][y] + " ");
                /*     */            }
            /*  34 */ fichero.write("\r\n");
            /*     */        }
        /*     */
        /*  37 */ fichero.close();
                    bw.close();
        /*     */    }
    /*     */
    /*     */ public static void dumpFile(int[][] m, String path, String name, List<Node> nodeList) throws IOException {
        /*  41 */ String sFile = name;
        /*     */
        /*  43 */ FileWriter file = new FileWriter(path + System.getProperty("file.separator") + sFile);
        /*  44 */ BufferedWriter bw = new BufferedWriter(new FileWriter(sFile));
        /*     */
        /*  46 */ file.write("\t");
        /*  47 */ for (int i = 0; i < nodeList.size(); i++) {
            /*  48 */ file.write(((Node) nodeList.get(i)).getNombre() + " \t");
            /*     */        }
        /*  50 */ file.write("\r\n");
        /*     */
        /*  52 */ for (int x = 0; x < m.length; x++) {
            /*  53 */ file.write(((Node) nodeList.get(x)).getNombre() + " \t");
            /*  54 */ for (int y = 0; y < m.length; y++) {
                /*  55 */ file.write(m[x][y] + " \t");
                /*     */            }
            /*  57 */ file.write("\r\n");
            /*     */        }
        /*     */
        /*  60 */ file.close();
        /*     */    }
    /*     */
    /*     */ public static int[][] dumpMatrix(String path) throws FileNotFoundException, IOException {
        /*  64 */ File file = new File(path);
        /*  65 */ FileReader fr = new FileReader(file);
        /*  66 */ BufferedReader br = new BufferedReader(fr);
        /*     */
        /*  68 */ int contI = 0;
        /*  69 */ int contJ = 0;
        /*     */ String line;
        /*  72 */ while ((line = br.readLine()) != null) {
            /*  73 */ String[] aux = line.split(" ");
            /*  74 */ contI = aux.length;
            /*  75 */ contJ++;
            /*     */        }
        /*     */
        /*  78 */ fr.close();
        /*  79 */ br.close();
        /*     */
        /*  81 */ file = new File(path);
        /*  82 */ fr = new FileReader(file);
        /*  83 */ br = new BufferedReader(fr);
        /*     */
        /*  85 */ int cont = 0;
        /*     */
        /*  88 */ int[][] m = new int[contI][contJ];
        /*     */
        /*  90 */ while ((line = br.readLine()) != null) {
            /*  91 */ String[] aux = line.split(" ");
            /*     */
            /*  93 */ for (int i = 0; i < aux.length; i++) {
                /*  94 */ m[cont][i] = Integer.parseInt(aux[i]);
                /*     */            }
            /*     */
            /*  97 */ cont++;
            /*     */        }
        /*     */
        /* 100 */ fr.close();
        /* 101 */ br.close();
        /*     */
        /* 103 */ return m;
        /*     */    } 

/*     */ }
