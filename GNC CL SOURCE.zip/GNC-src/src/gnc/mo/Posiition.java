/*    */ package gnc.mo;
/*    */ 
/*    */ public class Posiition
/*    */ {
/*    */   int realPosition;
/*    */   String nodeName;
/*    */ 
/*    */   public Posiition(int realPosition, String nodeName)
/*    */   {
/* 16 */     this.realPosition = realPosition;
/* 17 */     this.nodeName = nodeName;
/*    */   }
/*    */ 
/*    */   public String getNodeName() {
/* 21 */     return this.nodeName;
/*    */   }
/*    */ 
/*    */   public void setNodeName(String nodeName) {
/* 25 */     this.nodeName = nodeName;
/*    */   }
/*    */ 
/*    */   public int getRealPosition() {
/* 29 */     return this.realPosition;
/*    */   }
/*    */ 
/*    */   public void setRealPosition(int realPosition) {
/* 33 */     this.realPosition = realPosition;
/*    */   }
/*    */ }
