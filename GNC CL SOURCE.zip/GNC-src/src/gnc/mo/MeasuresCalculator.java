package gnc.mo;

import gnc.bbdd.BBDD;
import gnc.inputnetwork.RedEntrada;
import gnc.pojo.Edge;
import gnc.pojo.IGRN;
import gnc.pojo.ReadGRN;
import static java.lang.System.out;
import java.util.HashMap;
import gnc.utils.Utils;

public class MeasuresCalculator {

    private HashMap<Integer, Posiition> position = new HashMap();
    private int commonGenes = 0;
    private final int inf = Utils.infinite;
    private int[][]mIn;
    private int[][]mBD;
    private final DistFactory distanceFactory;
    private IDist DBD;
    private IDist DIN;
    private float[] coherenceMatrix;
    private IGRN inputGRN;
    private IGRN DBGRN;    
    private ReadGRN readIN = new ReadGRN();
    private ReadGRN readDB = new ReadGRN();  
    private String DBpath,INpath;
    
    public MeasuresCalculator(String DBpath, String INpath) {
        distanceFactory = DistFactory.getInstance();
        DBD = distanceFactory.createGRN("Floyd");
        DIN = distanceFactory.createGRN("Floyd");
        inputGRN = new RedEntrada();
        DBGRN = new BBDD();
        coherenceMatrix = new float[3];
        this.DBpath = DBpath;
        this.INpath = INpath;
                
    }
    
    
    public int getCommonGenes() {
        return commonGenes;
    }

    public void setCommonGenes(int commonGenes) {
        this.commonGenes = commonGenes;
    }

    public Integer searchNode(String name, HashMap<String, Integer> hashmap) {
        if (name.contains("﻿")) {
            String[] a = name.split("﻿");
            return (Integer) hashmap.get(a[1]);
        }
        return (Integer) hashmap.get(name);
    }

    public HashMap<Integer, Posiition> getPosition() {
        return this.position;
    }
    
   public void start(String BD,String input){
       out.print("Running: This task could take several minutes, please be patient\n");
       GNCThread.numExecuted=0;
       GNCThread threadDB = new GNCThread(DBGRN, readDB,"Database",BD, mBD, DBD,this,DBpath);
       GNCThread threadIN = new GNCThread(inputGRN, readIN,"Input Network", input, mIn, DIN,this,INpath);
       
       threadDB.start();
       threadIN.start();

       waitToCompletelyExecute();  
       
       out.print("Obtaining measures\n");
       coherenceMatrix = intersectionCalculator(inputGRN, mBD, mIn, readDB.getHmap(),DBGRN);
    }
   
   public static void waitToCompletelyExecute() {
        synchronized(GNCThread.main){
            try {
                if (GNCThread.numExecuted < 2) {
                    GNCThread.main.wait();
                }                           
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        } 
    }
   
    public float[] intersectionCalculator(IGRN input, int[][] databaseMatrix, int[][] inputMatrix, HashMap<String, Integer> hashmap,IGRN BD) {
        float[][] result;
        int commonCont = 0;
        Integer contDB = 0;
        float alfa = 0, beta = 0;
        float sum = 0;
        float sumUpperDiagonal = 0;
        float coherencePPV = 0, coherenceF = 0, coherenceRecall = 0;
        int TP = 0, FP = 0, TN = 0, FN = 0;
        float cont = (float)0.0;
        float[] coherence = new float[3];

        for (int i = 0; i < input.getNodeList().size(); i++) {
            contDB = hashmap.get(input.getNodeList().get(i).getNombre());
            if (contDB != null) {
                if (contDB >= 0) {
                    Posiition aux = new Posiition(i, input.getNodeList().get(i).getNombre());
                    position.put(commonCont, aux);
                    commonCont++;
                }
            }
            
        }  
        cont = (float)0;
        /////////////////////////////////////////////////////////////////////////
        if (commonCont>0) {
            out.print("Number of common genes:" + commonCont +"\n" );
            out.print("Final Step: Obtaining measures\n");
            //padre.update(padre.getGraphics());
            result = new float[commonCont][commonCont];
            int n = result.length;
            this.setCommonGenes(n);
            
            for (int i = 0; i < result.length; i++) {
                for (int j = 0; j < result.length; j++) {
                    if (i == j) {
                        result[i][j] = 0;
                    } else {
                        alfa = inputMatrix[position.get(i).getRealPosition()][position.get(j).getRealPosition()];
                        beta = databaseMatrix[hashmap.get(position.get(i).getNodeName())][hashmap.get(position.get(j).getNodeName())];
                        if (alfa < inf && beta < inf && (Math.abs(alfa - beta)==0)) {
                            TP++;
                        }else if(alfa < inf && beta < inf && alfa!=beta){
                            TN++;
                        }
                        sum = 1 / (((Math.abs(alfa - beta)) * Math.min(alfa, beta)) + 1);
                        result[i][j] = sum;
                    }

                }
                
                float valueAdd = (float)((float)Utils.ten/(float)input.getNodeList().size());
                cont+=valueAdd;
                if ((float)cont>=(float)Utils.unit) {                
                    Utils.updateProcess((int)cont);
                    Utils.printProcessValue();                    
                    cont = (float)0.0;
                }
                
            }

            //recorro la diagonal sup para sumar resultados
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (i < j) {
                        sumUpperDiagonal += result[i][j];
                    }
                }
            }

            sumUpperDiagonal = (float) sumUpperDiagonal / ((float) ((float) ((float) n * ((float) n - (float) 1)) / (float) 2));
       /////////////////////////////////////////////////////////////////////////
            cont = (float)0.0;
            for (int i = 0; i < input.getEdgeList().size(); i++) {
                boolean enc = false;
                for (int j = 0; j < BD.getEdgeList().size(); j++) {                
                    Edge inA = input.getEdgeList().get(i);
                    Edge bdA = BD.getEdgeList().get(j);                
                    if (inA.getOrigen().compareToIgnoreCase(bdA.getOrigen())==0 && inA.getDestino().compareToIgnoreCase(bdA.getDestino())==0 ) {
                        enc = true;
                        break;
                    }             
                }
                if (!enc) {
                    FP++;
                }        
                
                float valorASumar = (float)((float)Utils.ten/(float)input.getEdgeList().size());
                cont+=valorASumar;
                if ((float)cont>=(float)Utils.unit) {                
                    Utils.updateProcess((int)cont);
                    Utils.printProcessValue();                    
                    cont = (float)0.0;
                }
            }
                    
            cont = (float)0.0;
            //float resto = (float)Properties.maximo_barra - (float)padre.getBarra().getValue();
            for (int i = 0; i < BD.getEdgeList().size(); i++) {
                boolean enc = false;
                for (int j = 0; j < input.getEdgeList().size(); j++) {                
                    Edge inA = input.getEdgeList().get(j);
                    Edge bdA = BD.getEdgeList().get(i);                
                    if (inA.getOrigen().compareToIgnoreCase(bdA.getOrigen())==0 && inA.getDestino().compareToIgnoreCase(bdA.getDestino())==0 ) {
                        enc = true;
                        break;
                    }             
                }
                if (!enc) {
                    FN++;
                }
                
                float valorASumar = (float)((float)Utils.ten/(float)input.getEdgeList().size());
                cont+=valorASumar;
                if ((float)cont>=(float)Utils.unit) {                
                    Utils.updateProcess((int)cont);
                    Utils.printProcessValue();                    
                    cont = (float)0.0;
                }
                
            }         
            
            coherencePPV = ((float) TP / ((float) TP + (float) FP));
            coherenceRecall = ((float) TP / ((float) TP + (float) FN));
            coherenceF = (1 - (((float) 2 * (float) coherencePPV * (float) coherenceRecall) / ((float) coherencePPV + (float) coherenceRecall)));
            out.print("GNC measure:" + sumUpperDiagonal + "\n");
            out.print("F-Measure :" + coherenceF + "\n");
            out.print("PPV measure:" + coherencePPV + "\n");
            coherence[0] = sumUpperDiagonal;
            coherence[1] = coherencePPV;
            coherence[2] = coherenceF;
        }else{
            coherence[0] = 0;
            coherence[1] = 0;
            coherence[2] = 0;
            out.print("GNC measure:" + 0 + "\n");
            out.print("F-Measure :" + 0 + "\n");
            out.print("PPV measure:" + 0 + "\n");
        }
        return coherence;
    }

    public int[][] getmIn() {
        return mIn;
    }

    public void setmIn(int[][] mIn) {
        this.mIn = mIn;
    }

    public int[][] getmBD() {
        return mBD;
    }

    public void setmBD(int[][] mBD) {
        this.mBD = mBD;
    }

    public IDist getDBD() {
        return DBD;
    }

    public void setDBD(IDist DBD) {
        this.DBD = DBD;
    }

    public IDist getDIN() {
        return DIN;
    }

    public void setDIN(IDist DIN) {
        this.DIN = DIN;
    }

    public float[] getmCoherencia() {
        return coherenceMatrix;
    }

    public void setmCoherencia(float[] mCoherencia) {
        this.coherenceMatrix = mCoherencia;
    }

    public IGRN getInputGRN() {
        return inputGRN;
    }

    public void setInputGRN(IGRN inputGRN) {
        this.inputGRN = inputGRN;
    }

    public IGRN getGrnBD() {
        return DBGRN;
    }

    public void setGrnBD(IGRN grnBD) {
        this.DBGRN = grnBD;
    }

    public ReadGRN getLeeInput() {
        return readIN;
    }

    public void setLeeInput(ReadGRN leeInput) {
        this.readIN = leeInput;
    }

    public ReadGRN getReadDB() {
        return readDB;
    }

    public void setReadDB(ReadGRN readDB) {
        this.readDB = readDB;
    } 
    
}
