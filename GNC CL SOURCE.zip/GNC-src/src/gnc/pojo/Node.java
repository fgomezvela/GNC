/*    */ package gnc.pojo;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class Node
/*    */ {
/*    */   private String name;
/* 18 */   private List<Integer> idEdges = new ArrayList();
/*    */ 
/*    */   public Node(String name, List<Integer> idEdges)
/*    */   {
/* 22 */     this.name = name;
/* 23 */     this.idEdges = idEdges;
/*    */   }
/*    */ 
/*    */   public Node(String name)
/*    */   {
/* 28 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public List<Integer> getIdAristas()
/*    */   {
/* 33 */     return this.idEdges;
/*    */   }
/*    */ 
/*    */   public void setIdAristas(List<Integer> idEdges)
/*    */   {
/* 38 */     this.idEdges = idEdges;
/*    */   }
/*    */ 
/*    */   public String getNombre() {
/* 42 */     return this.name;
/*    */   }
/*    */ 
/*    */   public void setNombre(String name)
/*    */   {
/* 47 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public int[] cambiar(List<Integer> idEdges)
/*    */   {
/* 52 */     int[] aux = null;
/*    */ 
/* 54 */     for (int i = 0; i < idEdges.size(); i++)
/*    */     {
/* 56 */       aux[i] = ((Integer)idEdges.get(i)).intValue();
/*    */     }
/*    */ 
/* 59 */     return aux;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 65 */     if (obj == null)
/*    */     {
/* 67 */       return false;
/*    */     }
/* 69 */     if (getClass() != obj.getClass())
/*    */     {
/* 71 */       return false;
/*    */     }
/*    */ 
/* 74 */     Node other = (Node)obj;
/*    */ 
/* 76 */     if (this.name == null ? other.name != null : !this.name.equals(other.name))
/*    */     {
/* 78 */       return false;
/*    */     }
/* 80 */     if ((this.idEdges != other.idEdges) && ((this.idEdges == null) || (!this.idEdges.equals(other.idEdges))))
/*    */     {
/* 82 */       return false;
/*    */     }
/*    */ 
/* 85 */     return true;
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 91 */     int hash = 7;
/* 92 */     hash = 59 * hash + (this.name != null ? this.name.hashCode() : 0);
/* 93 */     return hash;
/*    */   }
/*    */ 
/*    */   public void addId(Integer in)
/*    */   {
/* 98 */     this.idEdges.add(in);
/*    */   }
/*    */ }


 