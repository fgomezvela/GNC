/*    */ package gnc.pojo;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashSet;
/*    */ import java.util.List;
/*    */ 
/*    */ public class GRN
/*    */   implements IGRN
/*    */ {
/* 20 */   private List<Node> nodeList = new ArrayList();
/* 21 */   private List<Edge> edgeList = new ArrayList();
/* 22 */   private HashSet<String> nodes = new HashSet();
/* 23 */   private HashSet<Edge> edges = new HashSet();
/*    */ 
/*    */   public GRN() {
/*    */   }
/*    */ 
/*    */   public HashSet<String> getNodes() {
/* 29 */     return this.nodes;
/*    */   }
/*    */ 
/*    */   public void setNode(HashSet<String> nodes) {
/* 33 */     this.nodes = nodes;
/*    */   }
/*    */ 
/*    */   public HashSet<Edge> getEdges() {
/* 37 */     return this.edges;
/*    */   }
/*    */ 
/*    */   public void setEdges(HashSet<Edge> edges) {
/* 41 */     this.edges = edges;
/*    */   }
/*    */ 
/*    */   public GRN(List<Node> nodeList, List<Edge> edgeList) {
/* 45 */     this.nodeList = nodeList;
/* 46 */     this.edgeList = edgeList;
/*    */   }
/*    */ 
/*    */   public List<Edge> getEdgeList()
/*    */   {
/* 51 */     return this.edgeList;
/*    */   }
/*    */ 
/*    */   public void setEdgeList(List<Edge> edgeList)
/*    */   {
/* 56 */     this.edgeList = edgeList;
/*    */   }
/*    */ 
/*    */   public List<Node> getNodeList()
/*    */   {
/* 61 */     return this.nodeList;
/*    */   }
/*    */ 
/*    */   public void setNodeList(List<Node> nodeList)
/*    */   {
/* 66 */     this.nodeList = nodeList;
/*    */   }
/*    */ 
/*    */   public void addEdge(Edge a)
/*    */   {
/* 71 */     this.edgeList.add(a);
/*    */   }
/*    */ 
/*    */   public void addNode(Node n)
/*    */   {
/* 76 */     this.nodeList.add(n);
/*    */   }
/*    */ 
/*    */   public Node searchName(String nombre)
/*    */   {
/* 81 */     Node aux = null;
/* 82 */     for (int i = 0; i < this.nodeList.size(); i++) {
/* 83 */       if (nombre.compareToIgnoreCase(((Node)this.nodeList.get(i)).getNombre()) == 0) {
/* 84 */         aux = (Node)this.nodeList.get(i);
/*    */       }
/*    */     }
/* 87 */     return aux;
/*    */   }
/*    */

 }

